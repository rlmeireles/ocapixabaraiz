# O Capixaba Raiz — V2

Versão com identidade capixaba, hero visual, acervo, categorias, CTA "Eu estava lá", WhatsApp e área No Rock.

## Deploy na Vercel
Envie esta pasta/ZIP no mesmo projeto via Vercel Drop. Next.js: 16.3.4.

## Próximos passos
- preencher TikTok/Facebook/Threads
- contador real + Web Analytics
- busca e páginas individuais do acervo
- integração com Google Drive para downloads
