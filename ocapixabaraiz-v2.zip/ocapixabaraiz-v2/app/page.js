const socials = [
  ['Instagram', 'https://www.instagram.com/ocapixabaraiz?stkn=Z2doYzdwbWxodmIz'],
  ['YouTube', 'https://youtube.com/@ocapixabaraiz?si=QbkDQbntcLG2CocA'],
  ['TikTok', '#'],
  ['Facebook', '#'],
  ['Threads', '#']
]

const categories = [
  ['🎸','Rock & Boates','Shows, casas noturnas, bandas e noites que marcaram época.'],
  ['🎉','Festas & Eventos','Carnavais, festivais, festas tradicionais e grandes encontros.'],
  ['🎤','Música Capixaba','Artistas, bandas, DJs, forró, rock e sons feitos no Espírito Santo.'],
  ['📍','Lugares','Praias, pontes, bairros e espaços que fazem parte da nossa memória.'],
  ['🧑‍🎤','Personagens','Gente que fez história, criou cenas e deixou sua marca.'],
  ['🗂️','História','Registros, curiosidades, fotos e documentos de outras épocas.']
]

const memories = [
  ['São Firmino','Rock • memória • fotos','Uma época que ficou marcada na memória de muita gente.'],
  ['Vitória Pop','Festival • música • arquivo','Bandas, histórias, imagens e vídeos de um dos eventos que movimentaram a cena capixaba.'],
  ['Boates & Rock','Noite • cultura • nostalgia','Casas, festas, shows e encontros que ajudaram a construir a cena do Espírito Santo.']
]

export default function Home() {
  const whatsapp = '5527998529934'
  const waBase = `https://wa.me/${whatsapp}`
  const waGeneral = `${waBase}?text=${encodeURIComponent('Olá! Quero enviar fotos, vídeos ou uma história para o acervo O Capixaba Raiz.')}`
  const waMemory = (name) => `${waBase}?text=${encodeURIComponent(`Olá! Eu estava lá e quero enviar fotos, vídeos ou contar uma história sobre ${name} para o O Capixaba Raiz.`)}`

  return (
    <main>
      <nav className="nav">
        <a className="brand" href="#top"><span>O CAPIXABA</span> RAIZ</a>
        <div className="navlinks"><a href="#acervo">Acervo</a><a href="#categorias">Categorias</a><a href="#envie">Envie sua história</a></div>
        <a className="navWa" href={waGeneral} target="_blank" rel="noreferrer">WhatsApp</a>
      </nav>

      <section id="top" className="hero">
        <div className="heroOverlay" />
        <div className="heroContent">
          <div className="eyebrow">MEMÓRIA • CULTURA • MÚSICA • ESPÍRITO SANTO</div>
          <h1>O CAPIXABA <em>RAIZ</em></h1>
          <h2>A memória do Espírito Santo mora aqui.</h2>
          <p>Fotos, vídeos, relatos, eventos, lugares e personagens que fazem parte da nossa história.</p>
          <div className="actions"><a className="primary" href="#acervo">Explorar o acervo</a><a className="secondary" href={waGeneral} target="_blank" rel="noreferrer">Enviar minha história</a></div>
          <div className="signature">Quem viveu, lembra. <strong>Quem não viveu, conhece aqui.</strong></div>
        </div>
      </section>

      <section className="numbers">
        <div><b>ES</b><span>100% capixaba</span></div><div><b>∞</b><span>memórias para preservar</span></div><div><b>24h</b><span>acervo disponível</span></div><div><b>Você</b><span>também faz parte</span></div>
      </section>

      <section id="acervo" className="section">
        <div className="sectionHead"><span>VOCÊ LEMBRA DISSO?</span><h2>Histórias que merecem continuar vivas.</h2><p>O acervo começa pequeno, mas cresce com cada foto, vídeo e relato enviado pela comunidade.</p></div>
        <div className="memoryGrid">
          {memories.map(([title,tag,text],i) => (
            <article className={`memoryCard memory${i+1}`} key={title}>
              <div className="memoryTag">{tag}</div><div className="memoryBody"><h3>{title}</h3><p>{text}</p><div className="cardActions"><span className="ghost">Ver história →</span><a href={waMemory(title)} target="_blank" rel="noreferrer">Eu estava lá ❤️</a></div></div>
            </article>
          ))}
        </div>
      </section>

      <section id="categorias" className="section categories">
        <div className="sectionHead"><span>EXPLORE O ESPÍRITO SANTO</span><h2>Uma memória para cada canto e cada época.</h2></div>
        <div className="categoryGrid">{categories.map(([icon,title,text]) => <article key={title}><div className="icon">{icon}</div><h3>{title}</h3><p>{text}</p></article>)}</div>
      </section>

      <section className="mapSection">
        <div><span>MAPA DA MEMÓRIA CAPIXABA</span><h2>De onde vem a sua história?</h2><p>Em breve você poderá explorar o acervo por cidade: Vitória, Serra, Vila Velha, Cariacica, Guarapari e todo o Espírito Santo.</p><button>Mapa interativo — em breve</button></div>
        <div className="esShape">ES<span>32 municípios<br/>e milhares de histórias</span></div>
      </section>

      <section id="envie" className="community">
        <div className="communityText"><span>EU ESTAVA LÁ</span><h2>Seu álbum antigo pode virar parte da história.</h2><p>Tem fotos de uma boate, show, banda, festa, praia, evento ou lugar antigo? Envie pelo WhatsApp. Informe quando foi, onde foi e, se souber, quem fotografou.</p><small>Ao enviar, informe também se autoriza a publicação e como deseja receber o crédito.</small></div>
        <a className="waBig" href={waGeneral} target="_blank" rel="noreferrer"><b>Enviar pelo WhatsApp</b><span>+55 27 99852-9934</span></a>
      </section>

      <section className="section network">
        <div className="sectionHead"><span>O CAPIXABA RAIZ EM TODO LUGAR</span><h2>Acompanhe, compartilhe e ajude o acervo a crescer.</h2></div>
        <div className="socialGrid">{socials.map(([name,url]) => <a className={url==='#'?'disabled':''} href={url} key={name} target={url==='#'?undefined:'_blank'} rel={url==='#'?undefined:'noreferrer'}>{name}<span>{url==='#'?'em breve':'abrir ↗'}</span></a>)}</div>
        <a className="norock" href="https://www.norock.com.br/" target="_blank" rel="noreferrer"><div><small>MEMÓRIA DA CENA ROCK CAPIXABA</small><h3>No Rock</h3><p>Uma referência importante para quem viveu e acompanha a cena rock do Espírito Santo.</p></div><b>Acessar norock.com.br ↗</b></a>
      </section>

      <footer><div className="footerBrand">O CAPIXABA <strong>RAIZ</strong></div><p>A memória do Espírito Santo mora aqui.</p><small>© 2026 O Capixaba Raiz • Espírito Santo</small></footer>
      <a className="floatWa" href={waGeneral} target="_blank" rel="noreferrer" aria-label="Enviar material pelo WhatsApp">✆</a>
    </main>
  )
}
